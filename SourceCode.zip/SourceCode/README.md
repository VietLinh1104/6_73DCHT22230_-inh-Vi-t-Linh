# EFMS - Enterprise Financial Management System

EFMS là hệ thống quản trị tài chính doanh nghiệp theo kiến trúc microservices. Hệ thống tập trung vào các nghiệp vụ kế toán lõi: quản lý đối tác, hóa đơn phải thu/phải trả, phê duyệt AP Bill, ghi nhận thanh toán, tài khoản ngân hàng, hệ thống tài khoản kế toán và bút toán kép tự động.

Tài liệu này mô tả cách hiểu hệ thống từ góc nhìn nghiệp vụ, kiến trúc triển khai, cách dùng giao diện web và cách dùng MCP Server để thao tác EFMS qua Claude AI.

## 1. Tổng quan hệ thống

### 1.1. Các thành phần chính

```text
Người dùng / Claude AI
        |
        | Web UI hoặc MCP Protocol
        v
efms-api-gateway :8080
        |
        +-- /api/identity/** -> efms-identity-service :8081
        +-- /api/core/**     -> efms-core-service :8082
        +-- /api/common/**   -> efms-common-service :8083
```

Các service trong hệ thống:

| Thành phần | Vai trò |
|---|---|
| `efms-react` | Frontend React/Vite cho người dùng nghiệp vụ |
| `efms-api-gateway` | Cổng vào duy nhất, route request, kiểm tra JWT, inject thông tin user/company/permissions |
| `efms-identity-service` | Đăng nhập, công ty, người dùng, vai trò, phân quyền RBAC, OAuth |
| `efms-core-service` | Hóa đơn, thanh toán, đối tác, tài khoản kế toán, ngân hàng, bút toán |
| `efms-common-service` | Comment, attachment, dữ liệu dùng chung theo entity |
| `efms-mcp-server` | Cầu nối giữa Claude AI và EFMS qua MCP HTTP transport |
| `efms-db` | PostgreSQL database và backup/schema tham khảo |

### 1.2. Nguyên tắc kiến trúc

- Mọi request bên ngoài đi qua API Gateway.
- Hệ thống dùng multi-tenancy theo `company_id`; dữ liệu nghiệp vụ phải được lọc theo công ty.
- Identity và Core không dùng foreign key trực tiếp ở database cho quan hệ cross-service; các service tham chiếu nhau bằng UUID.
- REST API trả về theo format chuẩn `ApiResponse<T>` gồm `status`, `message`, `data`.
- Quyền hạn dùng RBAC với dạng `RESOURCE:ACTION`, ví dụ `INVOICE:CREATE`, `PAYMENTS:READ`.
- Bút toán kép được hệ thống sinh tự động từ nghiệp vụ hóa đơn/thanh toán, không nhập tay ở UI.

## 2. Quy trình nghiệp vụ chính

### 2.1. Quy trình tổng quát

```text
Thiết lập dữ liệu nền
  -> Tạo đối tác, tài khoản kế toán, tài khoản ngân hàng

Tạo hóa đơn
  -> AP Bill hoặc AR Invoice ở trạng thái draft

Xác nhận hóa đơn
  -> AR Invoice: mở công nợ phải thu
  -> AP Bill: chuyển sang pending approval

Phê duyệt AP Bill
  -> Finance/Admin duyệt hoặc từ chối
  -> Có thể dùng AI phân tích rủi ro trước khi quyết định

Thanh toán
  -> Tạo payment
  -> Liên kết hóa đơn nếu cần
  -> Post payment để ghi sổ cái

Theo dõi
  -> Dashboard, journal entries, comment lịch sử phê duyệt
```

### 2.2. Đối tác

Đối tác là dữ liệu gốc cho hóa đơn và thanh toán.

- Khách hàng dùng cho AR Invoice.
- Nhà cung cấp dùng cho AP Bill.
- Cần có `partnerId` trước khi tạo hóa đơn hoặc thanh toán.

Màn hình liên quan: `/partners`

Quyền thường dùng:

| Thao tác | Quyền |
|---|---|
| Xem đối tác | `PARTNERS:READ` |
| Tạo đối tác | `PARTNERS:CREATE` |
| Cập nhật đối tác | `PARTNERS:UPDATE` |

### 2.3. Hóa đơn AP/AR

EFMS hỗ trợ hai loại hóa đơn:

| Loại | Ý nghĩa | Cần phê duyệt |
|---|---|---|
| AP Bill | Hóa đơn mua hàng, công nợ phải trả nhà cung cấp | Có |
| AR Invoice | Hóa đơn bán hàng, công nợ phải thu khách hàng | Không |

Luồng AP Bill:

```text
draft
  -> confirm
  -> status=open, approvalStatus=pending
  -> approve hoặc reject
```

Luồng AR Invoice:

```text
draft
  -> confirm
  -> status=open
```

Quy tắc quan trọng:

- Không approve trực tiếp hóa đơn đang `draft`; phải `confirm` trước.
- Chỉ xóa hóa đơn khi còn `draft`.
- Hóa đơn đã mở hoặc đã xử lý nên dùng nghiệp vụ `cancel` thay vì xóa.
- Khi tạo invoice line phải có `accountId`, `description`, `quantity`, `unitPrice`, `taxRate`.

Màn hình liên quan:

- `/invoices`
- `/invoices/create`
- `/invoices/:id/edit`

Quyền thường dùng:

| Thao tác | Quyền |
|---|---|
| Xem hóa đơn | `INVOICE:READ` |
| Tạo hóa đơn | `INVOICE:CREATE` |
| Cập nhật hóa đơn | `INVOICE:UPDATE` |
| Phê duyệt AP Bill | `INVOICE:FINANCE_MANAGER_REVIEW` |
| Hủy/xóa hóa đơn | `INVOICE:CANCEL`, `INVOICE:DELETE` |

### 2.4. Phê duyệt hóa đơn với AI

Với AP Bill đang chờ duyệt, người dùng có thể yêu cầu Claude phân tích trước khi quyết định. MCP tool `analyze_invoice_for_approval` sẽ tổng hợp:

- Chi tiết hóa đơn.
- KPI tài chính hiện tại.
- Tổng AR/AP.
- Dòng tiền thanh toán tháng này.
- Lịch sử giao dịch với đối tác.
- Các hóa đơn đang chờ xử lý.

Kết quả trả về gồm rủi ro, điểm tích cực, khuyến nghị và `Comment gợi ý`. Khi approve hoặc reject, nên dùng comment này để lưu lại căn cứ phê duyệt vào Common Service.

### 2.5. Thanh toán

Payment ghi nhận dòng tiền thực tế:

| Loại | Ý nghĩa |
|---|---|
| `CASH_IN` | Thu tiền từ khách hàng |
| `CASH_OUT` | Chi tiền cho nhà cung cấp |

Luồng thanh toán:

```text
Tra cứu bankAccountId
  -> Tra cứu partnerId
  -> Tạo payment
  -> Gắn invoiceId nếu thanh toán cho hóa đơn cụ thể
  -> post_payment
  -> Hệ thống tự sinh bút toán kép
```

Quy tắc quan trọng:

- Chỉ post khi đã kiểm tra đúng số tiền, đối tác, tài khoản ngân hàng và hóa đơn liên quan.
- Sau khi post, payment được xem là nghiệp vụ chính thức và không nên chỉnh sửa.

Màn hình liên quan:

- `/payments`
- `/payments/new`
- `/payments/:id/edit`

Quyền thường dùng:

| Thao tác | Quyền |
|---|---|
| Xem payment | `PAYMENTS:READ` |
| Tạo payment | `PAYMENTS:CREATE` |
| Cập nhật/phân bổ payment | `PAYMENTS:UPDATE` |
| Xóa payment trước khi post | `PAYMENTS:DELETE` |

### 2.6. Kế toán và ngân hàng

Các dữ liệu tham chiếu chính:

| Màn hình | Mục đích |
|---|---|
| `/accounting/accounts` | Chart of Accounts, dùng để lấy `accountId` khi tạo hóa đơn |
| `/finance/accounts` | Danh sách tài khoản ngân hàng, dùng để lấy `bankAccountId` khi tạo payment |
| Journal Entries | Xem bút toán kép hệ thống tự sinh |

## 3. Cách sử dụng qua giao diện web

### 3.1. Đăng nhập

1. Mở frontend EFMS.
2. Đăng nhập bằng tài khoản đã được cấp.
3. Sau khi đăng nhập, Gateway sẽ dùng JWT để xác thực và các service nội bộ nhận thông tin user qua header do Gateway inject.

### 3.2. Tạo AP Bill

1. Vào `/partners`, kiểm tra hoặc tạo nhà cung cấp.
2. Vào `/accounting/accounts`, xác định tài khoản kế toán phù hợp.
3. Vào `/invoices/create`.
4. Chọn loại hóa đơn AP Bill.
5. Nhập đối tác, ngày hóa đơn, hạn thanh toán và các dòng hóa đơn.
6. Lưu draft.
7. Bấm xác nhận để chuyển sang trạng thái chờ phê duyệt.

### 3.3. Phê duyệt AP Bill

1. Vào danh sách hóa đơn hoặc danh sách task chờ duyệt.
2. Mở chi tiết hóa đơn.
3. Kiểm tra đối tác, số tiền, dòng hàng, tài khoản kế toán và chứng từ liên quan.
4. Duyệt hoặc từ chối.
5. Nếu dùng Claude AI, yêu cầu phân tích hóa đơn trước rồi dùng comment gợi ý để lưu lý do phê duyệt.

### 3.4. Ghi nhận thanh toán

1. Vào `/finance/accounts`, kiểm tra tài khoản ngân hàng.
2. Vào `/payments/new`.
3. Chọn `CASH_IN` hoặc `CASH_OUT`.
4. Chọn đối tác, tài khoản ngân hàng, số tiền, ngày thanh toán.
5. Gắn hóa đơn nếu payment dùng để thanh toán cho hóa đơn cụ thể.
6. Lưu payment.
7. Kiểm tra lại và post payment để ghi sổ.

## 4. Cách sử dụng MCP Server với Claude AI

### 4.1. MCP Server dùng để làm gì?

`efms-mcp-server` cho phép Claude AI thao tác EFMS bằng ngôn ngữ tự nhiên. Người dùng có thể hỏi:

```text
Cho tôi xem dashboard tài chính hiện tại.
Có AP Bill nào đang chờ duyệt không?
Phân tích hóa đơn <invoiceId> xem có nên phê duyệt không.
Tạo thanh toán 5 triệu cho nhà cung cấp ABC từ tài khoản Vietcombank.
```

Claude sẽ gọi MCP tool phù hợp, MCP Server gọi EFMS API qua Gateway, rồi trả kết quả lại cho người dùng.

### 4.2. Luồng kết nối MCP

```text
Claude Desktop
    |
    | HTTP MCP request: POST /mcp
    | Authorization: Bearer <access_token>
    v
efms-mcp-server :3000
    |
    | Verify token qua Identity Service
    v
efms-api-gateway :8080
    |
    +-- /api/identity/auth/me
    +-- /api/core/v1/**
    +-- /api/common/v1/**
```

MCP Server không tự mở browser. Claude Desktop dùng OAuth metadata để đăng nhập và lấy token. Mỗi request đến `/mcp` phải có `Authorization: Bearer <token>`.

### 4.3. Cấu hình môi trường MCP Server

```env
PORT=3000
PUBLIC_EFMS_BASE_URL=http://efms-api-gateway:8080
PUBLIC_MCP_BASE_URL=http://localhost:8085
```

Ý nghĩa:

| Biến | Mục đích |
|---|---|
| `PORT` | Port chạy MCP Server |
| `PUBLIC_EFMS_BASE_URL` | Base URL của API Gateway để MCP gọi EFMS API |
| `PUBLIC_MCP_BASE_URL` | Base URL public của MCP Server nếu cần expose ra ngoài |

Khi chạy local, thường dùng:

```env
PORT=3000
PUBLIC_EFMS_BASE_URL=http://localhost:8080
PUBLIC_MCP_BASE_URL=http://localhost:3000
```

### 4.4. Chạy MCP Server local

```bash
cd efms-mcp-server
npm install
npm run dev
```

Hoặc build và chạy production:

```bash
cd efms-mcp-server
npm run build
npm start
```

Kiểm tra server:

```bash
curl http://localhost:3000/mcp
```

Kết quả kỳ vọng:

```json
{
  "name": "efms-mcp-server",
  "version": "1.0.0"
}
```

### 4.5. Cấu hình Claude Desktop

Để kết nối Claude với MCP Server của EFMS:

1. Truy cập Claude.
2. Mở mục `Customize`.
3. Chọn `Connectors`.
4. Nhấn dấu `+`.
5. Chọn `Add custom connector`.
6. Nhập thông tin kết nối:

| Trường | Giá trị |
|---|---|
| `NAME` | `EFMS` |
| `MCP Server URL` | `https://mcp.hnhdecor.com/mcp` |
| `OAuth Client ID` | `claude-connector` |
| `OAuth Client Secret` | `scXLlfmeZSXIcCxu8nbWbwzq` |

7. Lưu connector.
8. Claude sẽ mở luồng đăng nhập OAuth của EFMS.
9. Đăng nhập bằng tài khoản EFMS.
10. Sau khi kết nối thành công, có thể hỏi Claude các câu như: "Cho tôi xem dashboard tài chính hiện tại" hoặc "Có hóa đơn nào đang chờ duyệt không?"

Lưu ý:

- Identity Service phải có OAuth client tương ứng với `client_id`.
- API Gateway phải expose metadata endpoint OAuth.
- MCP Server phải truy cập được `PUBLIC_EFMS_BASE_URL`.
- Nếu chạy sau Nginx/proxy, phải forward header `Authorization`.
- Không chia sẻ `OAuth Client Secret` ra ngoài phạm vi người dùng được phép kết nối hệ thống.

### 4.6. Danh sách MCP tools hiện có

| Nhóm | Tool | Mục đích |
|---|---|---|
| Utility | `check_connection` | Kiểm tra kết nối MCP |
| Dashboard | `get_dashboard_summary` | Lấy KPI tài chính, AR/AP, payment tháng này, hóa đơn chờ duyệt |
| Invoices | `list_invoices` | Liệt kê hóa đơn theo filter |
| Invoices | `get_invoice_details` | Xem chi tiết hóa đơn và invoice lines |
| Invoices | `create_invoice` | Tạo AP Bill hoặc AR Invoice ở trạng thái draft |
| Invoices | `confirm_invoice` | Xác nhận hóa đơn |
| Invoices | `approve_invoice` | Phê duyệt AP Bill đang pending |
| Invoices | `reject_invoice` | Từ chối AP Bill đang pending |
| Invoices | `cancel_invoice` | Hủy hóa đơn |
| Invoices | `delete_invoice` | Xóa hóa đơn khi còn draft |
| Approval | `list_pending_tasks` | Liệt kê AP Bill đang chờ duyệt |
| Approval | `analyze_invoice_for_approval` | AI phân tích rủi ro và khuyến nghị phê duyệt |
| Comments | `list_invoice_comments` | Xem lịch sử comment của hóa đơn |
| Partners | `list_partners` | Tìm kiếm đối tác |
| Partners | `get_partner` | Xem chi tiết đối tác |
| Partners | `create_partner` | Tạo khách hàng hoặc nhà cung cấp |
| Payments | `list_payments` | Liệt kê thanh toán |
| Payments | `get_payment` | Xem chi tiết thanh toán |
| Payments | `create_payment` | Tạo payment |
| Payments | `post_payment` | Post payment để ghi sổ |
| Reference | `list_accounts` | Tra cứu Chart of Accounts |
| Reference | `list_journals` | Xem bút toán kế toán |
| Reference | `list_bank_accounts` | Tra cứu tài khoản ngân hàng |

### 4.7. Ví dụ hội thoại với Claude

Xem tổng quan:

```text
Cho tôi xem dashboard tài chính hiện tại.
```

Tạo AP Bill:

```text
Tìm nhà cung cấp tên Công ty ABC.
Tìm tài khoản chi phí phù hợp để ghi nhận dịch vụ tư vấn.
Tạo AP Bill cho Công ty ABC ngày 2026-06-05, hạn thanh toán 2026-06-20,
gồm 1 dòng dịch vụ tư vấn số lượng 1 đơn giá 10000000 thuế 10%.
```

Phê duyệt có phân tích AI:

```text
Có hóa đơn nào đang chờ tôi phê duyệt không?
Phân tích hóa đơn <invoiceId> xem có nên duyệt không.
Nếu khuyến nghị phù hợp thì phê duyệt và lưu comment gợi ý của AI.
```

Ghi nhận thanh toán:

```text
Liệt kê tài khoản ngân hàng của công ty.
Tạo thanh toán CASH_OUT 5000000 cho nhà cung cấp <partnerId>,
từ tài khoản ngân hàng <bankAccountId>, ngày 2026-06-05,
liên kết với hóa đơn <invoiceId>.
Sau khi tôi xác nhận, post thanh toán đó.
```

## 5. Chạy hệ thống local

### 5.1. Database

```bash
cd efms-db
docker compose up -d
```

PostgreSQL mặc định:

| Thuộc tính | Giá trị |
|---|---|
| Host | `localhost` |
| Port | `5432` |
| Database | `efms` |
| User | `efms` |
| Password | `123456` |

Database sử dụng PostgreSQL và schema EFMS v4, bao gồm dữ liệu Identity, Core và Common.

### 5.2. Backend services

Hệ thống backend gồm các service Spring Boot chính:

- `efms-api-gateway`
- `efms-identity-service`
- `efms-core-service`
- `efms-common-service`

Chạy từng service bằng Maven:

```bash
mvn spring-boot:run
```

Thứ tự khuyến nghị:

1. Database.
2. Identity Service.
3. Core Service.
4. Common Service.
5. API Gateway.
6. MCP Server.
7. Frontend.

### 5.3. Frontend

```bash
cd efms-react
npm install
npm run dev
```

Frontend dùng Vite. Khi cấu hình frontend, đảm bảo base URL API trỏ về API Gateway.

## 6. Triển khai Nginx cho MCP/API

Khi expose MCP qua domain, proxy phải giữ kết nối HTTP streaming và forward `Authorization`.

Ví dụ các cấu hình cần có cho MCP:

```nginx
proxy_set_header Authorization $http_authorization;
proxy_pass_header Authorization;
proxy_set_header Connection "keep-alive";
proxy_buffering off;
proxy_cache off;
chunked_transfer_encoding on;
proxy_read_timeout 86400;
```

## 7. Lỗi thường gặp

| Lỗi | Nguyên nhân thường gặp | Cách xử lý |
|---|---|---|
| `401 Unauthorized` khi gọi `/mcp` | Thiếu Bearer token hoặc token hết hạn | Đăng nhập lại OAuth trong Claude Desktop, kiểm tra header `Authorization` |
| `Missing companyId` | Token hợp lệ nhưng user chưa gắn công ty | Kiểm tra user trong Identity Service |
| `403 Forbidden` | User thiếu permission | Kiểm tra role và permissions |
| `400 Bad Request` khi tạo hóa đơn | Thiếu field bắt buộc hoặc sai enum | Kiểm tra `invoiceType`, `partnerId`, `accountId`, `lines` |
| Không thấy AP Bill chờ duyệt | Hóa đơn chưa confirm hoặc không phải AP Bill | Confirm hóa đơn, kiểm tra `status=open` và `approvalStatus=pending` |
| Không lưu được comment khi approve/reject | Common Service chưa chạy hoặc endpoint lỗi | Kiểm tra `efms-common-service` và route `/api/common/**` |
| MCP chạy sau Nginx nhưng Claude lỗi auth | Proxy không forward Authorization hoặc buffering streaming | Kiểm tra cấu hình Nginx |
