import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { createEfmsClient } from "../client/efmsClient.js";
import fs from "fs";

const LOG_FILE = "/tmp/efms-mcp.log";
function log(msg: string) {
  fs.appendFileSync(LOG_FILE, `[${new Date().toISOString()}] ${msg}\n`);
}

export interface McpContext {
  token: string;
  companyId?: string;
}

export function registerEfmsTools(server: McpServer, ctx: McpContext) {
  const client = createEfmsClient(ctx.token, ctx.companyId);

  const handleError = (error: any) => {
    log(`ERROR: ${error.message} | Status: ${error.response?.status} | URL: ${error.config?.url}`);
    return {
      content: [
        {
          type: "text" as const,
          text: `Loi API: ${error.message} (Status: ${error.response?.status})\nResponse: ${JSON.stringify(error.response?.data || "No data")}`,
        },
      ],
      isError: true,
    };
  };

  const formatVND = (amount: number) =>
    new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(amount ?? 0);

  // ── Utility ────────────────────────────────────────────────────────────────

  server.tool("check_connection", "Kiem tra ket noi den EFMS", {}, async () => {
    return { content: [{ type: "text" as const, text: "Ket noi on dinh!" }] };
  });

  // ── Dashboard ──────────────────────────────────────────────────────────────

  server.tool(
    "get_dashboard_summary",
    "Lay tong quan du lieu tai chinh: KPI (tong AR/AP/thanh toan thang nay, so hoa don cho duyet), phan bo trang thai hoa don, doanh thu/chi phi 6 thang gan nhat, hoa don can xu ly va thanh toan gan day.",
    {},
    async () => {
      try {
        const response = await client.get("/api/core/v1/dashboard/summary", {
          params: { companyId: ctx.companyId },
        });
        const data = response.data.data;

        let summary = "## Tong quan Dashboard EFMS\n\n";
        const kpi = data.kpi;

        summary += "### KPI Tai chinh\n";
        summary += `- Tong Phai Thu (AR): ${formatVND(kpi.totalAr)}\n`;
        summary += `- Tong Phai Tra (AP): ${formatVND(kpi.totalAp)}\n`;
        summary += `- Thanh toan thang nay: ${formatVND(kpi.paymentsThisMonth)}\n`;
        summary += `- Hoa don cho phe duyet: ${kpi.pendingApprovalCount} hoa don\n\n`;

        if (data.invoiceStatusStats?.length > 0) {
          summary += "### Phan bo Hoa don theo Trang thai\n";
          data.invoiceStatusStats.forEach((s: any) => {
            summary += `- ${s.name}: ${s.value}\n`;
          });
          summary += "\n";
        }

        if (data.monthlyFlow?.length > 0) {
          summary += "### Doanh thu & Chi phi 6 thang (trieu VND)\n";
          data.monthlyFlow.forEach((m: any) => {
            summary += `- ${m.month}: Doanh thu ${m.revenue}M | Chi phi ${m.expense}M\n`;
          });
          summary += "\n";
        }

        if (data.pendingInvoices?.length > 0) {
          summary += `### Hoa don can xu ly (${data.pendingInvoices.length} gan nhat)\n`;
          data.pendingInvoices.forEach((inv: any) => {
            const label =
              inv.approvalStatus === "pending"
                ? "Cho duyet"
                : inv.status === "draft"
                  ? "Nhap"
                  : inv.status;
            let line = `- [${inv.invoiceType}] ${inv.partnerName} - ${formatVND(inv.totalAmount)} - ${label}`;
            if (inv.invoiceNumber) line += ` (${inv.invoiceNumber})`;
            summary += line + "\n";
          });
          summary += "\n";
        }

        if (data.recentPayments?.length > 0) {
          summary += "### Thanh toan gan day\n";
          data.recentPayments.forEach((p: any) => {
            const posted = p.posted ? "Da post" : "Cho post";
            summary += `- ${p.partnerName} - ${formatVND(p.amount)} - ${p.paymentDate} - ${posted}\n`;
          });
        }

        return {
          content: [{ type: "text" as const, text: summary }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  // ── Invoices — List & Read ─────────────────────────────────────────────────

  server.tool(
    "list_invoices",
    "Liet ke danh sach hoa don, co the loc theo trang thai (draft/open/cancelled), loai (AP_BILL/AR_INVOICE), doi tac, ngay",
    {
      status: z.string().optional().describe("draft | open | cancelled"),
      invoiceType: z.string().optional().describe("AP_BILL | AR_INVOICE"),
      partnerId: z.string().optional(),
      fromDate: z.string().optional().describe("ISO date, e.g. 2025-01-01"),
      toDate: z.string().optional().describe("ISO date, e.g. 2025-12-31"),
      page: z.number().default(0),
      size: z.number().default(20),
    },
    async (params) => {
      try {
        const response = await client.get("/api/core/v1/invoices", {
          params: { ...params, companyId: ctx.companyId },
        });
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "get_invoice_details",
    "Lay chi tiet mot hoa don bao gom danh sach cac dong hang (invoice lines)",
    { id: z.string().describe("UUID cua hoa don") },
    async ({ id }) => {
      try {
        const response = await client.get(`/api/core/v1/invoices/${id}`);
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  // ── Invoices — Write ───────────────────────────────────────────────────────

  server.tool(
    "create_invoice",
    "Tao hoa don AP Bill (hoa don mua hang, can phe duyet) hoac AR Invoice (hoa don ban hang). Hoa don duoc tao o trang thai draft.",
    {
      invoiceType: z.enum(["AP", "AR"]).describe("AP: mua hang (AP Bill, can phe duyet) | AR: ban hang (AR Invoice)"),
      partnerId: z.string().describe("UUID cua doi tac"),
      invoiceDate: z.string().describe("Ngay hoa don, dinh dang ISO: 2025-06-01"),
      dueDate: z.string().optional().describe("Ngay den han thanh toan"),
      lines: z
        .array(
          z.object({
            accountId: z.string().describe("UUID tai khoan ke toan tu COA (dung list_accounts de tra cuu)"),
            description: z.string().describe("Mo ta mat hang / dich vu (bat buoc)"),
            quantity: z.number().min(0.01).default(1).describe("So luong (BigDecimal, >= 0.01)"),
            unitPrice: z.number().min(0).describe("Don gia, vi du: 1500000"),
            taxRate: z.number().min(0).default(0).describe("Ty le thue % (bat buoc, nhap 0 neu khong co thue, 10 neu thue 10%)"),
          })
        )
        .min(1)
        .describe("Danh sach dong hang tren hoa don (toi thieu 1 dong)"),
    },
    async (params) => {
      try {
        const response = await client.post("/api/core/v1/invoices", {
          ...params,
          companyId: ctx.companyId,
        });
        const inv = response.data.data;
        return {
          content: [
            {
              type: "text" as const,
              text: `✅ Tao hoa don thanh cong!\nID: ${inv.id}\nSo: ${inv.invoiceNumber ?? "(chua co)"}\nLoai: ${inv.invoiceType} | Trang thai: ${inv.status}\nTong tien: ${formatVND(inv.totalAmount)}\n\n${JSON.stringify(inv, null, 2)}`,
            },
          ],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "confirm_invoice",
    "Xac nhan hoa don chuyen tu draft sang open. Voi AP Bill, sau buoc nay hoa don se co trang thai phe duyet la pending.",
    { id: z.string().describe("UUID cua hoa don can xac nhan") },
    async ({ id }) => {
      try {
        const response = await client.post(`/api/core/v1/invoices/${id}/confirm`);
        const inv = response.data.data;
        return {
          content: [
            {
              type: "text" as const,
              text: `✅ Xac nhan thanh cong!\nTrang thai: ${inv.status} | Phe duyet: ${inv.approvalStatus ?? "N/A"}\n\n${JSON.stringify(inv, null, 2)}`,
            },
          ],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "approve_invoice",
    "Phe duyet AP Bill dang cho duyet (approval_status=pending). Sau khi phe duyet, he thong se tu dong tao but toan ke toan va luu comment danh gia vao Common Service. Neu truoc do da chay analyze_invoice_for_approval, hay lay noi dung 'Comment goi y' trong bao cao do va dien vao tham so comment.",
    {
      id: z.string().describe("UUID cua hoa don AP Bill"),
      comment: z.string().optional().describe("Nhan xet / ly do phe duyet. Neu da co bao cao phan tich AI, dung 'Comment goi y' tu bao cao lam gia tri cho tham so nay."),
    },
    async ({ id, comment }) => {
      try {
        // 1. Goi Core Service de phe duyet hoa don
        const response = await client.post(`/api/core/v1/invoices/${id}/approve`);
        const inv = response.data.data;

        // 2. Luu comment vao Common Service neu co noi dung
        let commentResult = "(khong co comment)";
        if (comment) {
          try {
            await client.post("/api/common/v1/comments", {
              referenceId: id,
              referenceType: "invoices",
              content: comment,
            });
            commentResult = `Da luu comment vao Common Service: "${comment}"`;
          } catch (commentErr: any) {
            commentResult = `⚠️ Phe duyet thanh cong nhung luu comment that bai: ${commentErr.message}`;
          }
        }

        return {
          content: [
            {
              type: "text" as const,
              text: `✅ Phe duyet thanh cong!\nTrang thai phe duyet: ${inv.approvalStatus}\n${commentResult}\n\n${JSON.stringify(inv, null, 2)}`,
            },
          ],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "reject_invoice",
    "Tu choi AP Bill dang cho duyet (approval_status=pending). Comment ly do tu choi se duoc luu vao Common Service. Neu truoc do da chay analyze_invoice_for_approval, hay lay noi dung 'Comment goi y' trong bao cao do va dien vao tham so comment.",
    {
      id: z.string().describe("UUID cua hoa don AP Bill"),
      comment: z.string().describe("Ly do tu choi (bat buoc). Neu da co bao cao phan tich AI, dung 'Comment goi y' tu bao cao lam gia tri cho tham so nay."),
    },
    async ({ id, comment }) => {
      try {
        // 1. Goi Core Service de tu choi hoa don
        const response = await client.post(`/api/core/v1/invoices/${id}/reject`);
        const inv = response.data.data;

        // 2. Luu ly do tu choi vao Common Service
        let commentResult = "";
        try {
          await client.post("/api/common/v1/comments", {
            referenceId: id,
            referenceType: "invoices",
            content: comment,
          });
          commentResult = `Da luu ly do vao Common Service: "${comment}"`;
        } catch (commentErr: any) {
          commentResult = `⚠️ Tu choi thanh cong nhung luu comment that bai: ${commentErr.message}`;
        }

        return {
          content: [
            {
              type: "text" as const,
              text: `🚫 Da tu choi hoa don.\nTrang thai phe duyet: ${inv.approvalStatus}\n${commentResult}\n\n${JSON.stringify(inv, null, 2)}`,
            },
          ],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "cancel_invoice",
    "Huy hoa don (bat ky trang thai nao). Hanh dong nay khong the hoan tac.",
    { id: z.string().describe("UUID cua hoa don can huy") },
    async ({ id }) => {
      try {
        const response = await client.post(`/api/core/v1/invoices/${id}/cancel`);
        return {
          content: [
            {
              type: "text" as const,
              text: `🚫 Huy hoa don thanh cong.\n\n${JSON.stringify(response.data.data, null, 2)}`,
            },
          ],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "delete_invoice",
    "Xoa hoa don (chi cho phep khi status=draft)",
    { id: z.string().describe("UUID cua hoa don can xoa") },
    async ({ id }) => {
      try {
        await client.delete(`/api/core/v1/invoices/${id}`);
        return {
          content: [{ type: "text" as const, text: `🗑️ Da xoa hoa don ${id}.` }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  // ── Invoice Approval Tasks ─────────────────────────────────────────────────

  server.tool(
    "list_pending_tasks",
    "Liet ke danh sach AP Bill dang cho phe duyet (status=open, approvalStatus=pending)",
    {
      page: z.number().default(0),
      size: z.number().default(20),
    },
    async (params) => {
      try {
        const response = await client.get("/api/core/v1/invoice-tasks/tasks", {
          params: { ...params, companyId: ctx.companyId },
        });
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "list_invoice_comments",
    "Xem lich su comment (lich su phe duyet, ghi chu, nhan xet AI) cua mot hoa don tu Common Service. Dung sau khi approve/reject hoac de kiem tra ai da binh luan gi ve hoa don nay.",
    {
      invoiceId: z.string().describe("UUID cua hoa don can xem comment"),
    },
    async ({ invoiceId }) => {
      try {
        const response = await client.get(
          `/api/common/v1/comments/reference/invoices/${invoiceId}`
        );
        const comments: any[] = response.data.data ?? [];

        if (comments.length === 0) {
          return {
            content: [{ type: "text" as const, text: "Hoa don nay chua co comment nao." }],
          };
        }

        let text = `## Lich su Comment — Hoa don ${invoiceId.slice(0, 8)}...\n\n`;
        comments.forEach((c: any, i: number) => {
          const author = c.authorName ?? c.createdBy ?? "He thong";
          const date = c.createdAt ? new Date(c.createdAt).toLocaleString("vi-VN") : "";
          text += `**${i + 1}. ${author}** (${date})\n`;
          text += `> ${c.content}\n\n`;
        });

        return {
          content: [{ type: "text" as const, text }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  // ── ⭐ AI Analysis: Goi y phe duyet ──────────────────────────────────────

  server.tool(
    "analyze_invoice_for_approval",
    `Phan tich toan dien mot AP Bill de dua ra khuyen nghi PHE DUYET hoac TU CHOI dua tren tinh hinh tai chinh tong the cua cong ty.
Tool nay tong hop du lieu tu nhieu nguon: chi tiet hoa don, lich su giao dich voi doi tac, KPI tai chinh hien tai (tong AP/AR, dong tien thang nay) va cac hoa don cho xu ly.
Ket qua tra ve bao gom: danh gia rui ro, cac chi so tai chinh lien quan, va mot khuyen nghi ro rang co giai thich.`,
    {
      invoiceId: z.string().describe("UUID cua AP Bill can phan tich"),
    },
    async ({ invoiceId }) => {
      try {
        // Thu thap du lieu song song
        const [invoiceRes, dashboardRes, partnerInvoicesRes] = await Promise.allSettled([
          client.get(`/api/core/v1/invoices/${invoiceId}`),
          client.get("/api/core/v1/dashboard/summary", { params: { companyId: ctx.companyId } }),
          client.get("/api/core/v1/invoices", {
            params: { companyId: ctx.companyId, size: 50 },
          }),
        ]);

        const invoice =
          invoiceRes.status === "fulfilled" ? invoiceRes.value.data.data : null;
        const dashboard =
          dashboardRes.status === "fulfilled" ? dashboardRes.value.data.data : null;
        const allInvoices =
          partnerInvoicesRes.status === "fulfilled"
            ? (partnerInvoicesRes.value.data.data?.content ?? [])
            : [];

        if (!invoice) {
          return {
            content: [{ type: "text" as const, text: "❌ Khong tim thay hoa don voi ID nay." }],
            isError: true,
          };
        }

        // --- Tinh toan chi so ---
        const invoiceAmount: number = invoice.totalAmount ?? 0;
        const kpi = dashboard?.kpi ?? {};
        const totalAp: number = kpi.totalAp ?? 0;
        const totalAr: number = kpi.totalAr ?? 0;
        const paymentsThisMonth: number = kpi.paymentsThisMonth ?? 0;
        const pendingApprovalCount: number = kpi.pendingApprovalCount ?? 0;

        // Lich su doi tac
        const partnerInvoices: any[] = allInvoices.filter(
          (inv: any) => inv.partnerId === invoice.partnerId && inv.id !== invoiceId
        );
        const partnerApproved = partnerInvoices.filter(
          (inv: any) => inv.approvalStatus === "approved"
        ).length;
        const partnerRejected = partnerInvoices.filter(
          (inv: any) => inv.approvalStatus === "rejected"
        ).length;
        const partnerTotal = partnerInvoices.length;

        // Ty le AP/AR — kha nang thanh toan
        const apArRatio = totalAr > 0 ? totalAp / totalAr : null;
        // Hoa don nay chiem bao nhieu % AP hien tai
        const invoiceAsPercentAp = totalAp > 0 ? (invoiceAmount / totalAp) * 100 : 0;

        // --- Danh gia rui ro ---
        const risks: string[] = [];
        const positives: string[] = [];

        if (apArRatio !== null && apArRatio > 0.8) {
          risks.push(`Ty le AP/AR cao (${(apArRatio * 100).toFixed(1)}%): cong ty dang co nhieu cong no hon phai thu — ap luc dong tien lon.`);
        } else if (apArRatio !== null) {
          positives.push(`Ty le AP/AR lanh manh (${(apArRatio * 100).toFixed(1)}%): cong ty co kha nang thanh toan tot.`);
        }

        if (invoiceAsPercentAp > 30) {
          risks.push(`Gia tri hoa don nay chiem ${invoiceAsPercentAp.toFixed(1)}% tong AP hien tai — anh huong dang ke den cong no.`);
        } else {
          positives.push(`Gia tri hoa don chiem ${invoiceAsPercentAp.toFixed(1)}% tong AP — muc doc lap, khong gay ap luc lon.`);
        }

        if (pendingApprovalCount > 5) {
          risks.push(`Hien co ${pendingApprovalCount} hoa don khac dang cho phe duyet — can uu tien xu ly theo thu tu.`);
        }

        if (paymentsThisMonth < invoiceAmount * 0.5) {
          risks.push(`Dong tien thanh toan thang nay (${formatVND(paymentsThisMonth)}) thap so voi gia tri hoa don — co the gap kho khan thanh toan ngay.`);
        } else {
          positives.push(`Dong tien thang nay (${formatVND(paymentsThisMonth)}) du manh de xu ly thanh toan.`);
        }

        if (partnerTotal > 0) {
          const approvalRate = (partnerApproved / partnerTotal) * 100;
          if (approvalRate >= 80) {
            positives.push(`Doi tac co lich su tot: ${partnerApproved}/${partnerTotal} hoa don truoc duoc phe duyet (${approvalRate.toFixed(0)}%).`);
          } else if (partnerRejected > partnerApproved) {
            risks.push(`Doi tac co nhieu hoa don bi tu choi truoc day (${partnerRejected}/${partnerTotal}) — can kiem tra ky.`);
          }
        } else {
          risks.push("Doi tac moi, chua co lich su giao dich trong he thong — nen xac minh them.");
        }

        // --- Khuyen nghi ---
        const riskScore = risks.length;
        let recommendation: string;
        let recommendationIcon: string;

        if (riskScore === 0) {
          recommendation = "PHE DUYET";
          recommendationIcon = "✅";
        } else if (riskScore === 1) {
          recommendation = "PHE DUYET (luu y rui ro nho)";
          recommendationIcon = "✅⚠️";
        } else if (riskScore === 2) {
          recommendation = "XEM XET KY — co the phe duyet neu da xac minh";
          recommendationIcon = "⚠️";
        } else {
          recommendation = "DE NGHI TU CHOI hoac yeu cau them tai lieu";
          recommendationIcon = "🚫";
        }

        // --- Xay dung bao cao ---
        let report = `# 📊 Bao cao Phan tich Phe duyet Hoa don\n\n`;
        report += `## Thong tin Hoa don\n`;
        report += `- **So hoa don**: ${invoice.invoiceNumber ?? "(chua co)"}\n`;
        report += `- **Loai**: ${invoice.invoiceType}\n`;
        report += `- **Doi tac**: ${invoice.partnerName ?? invoice.partnerId}\n`;
        report += `- **Ngay hoa don**: ${invoice.invoiceDate}\n`;
        report += `- **Den han**: ${invoice.dueDate ?? "Khong co"}\n`;
        report += `- **Gia tri**: **${formatVND(invoiceAmount)}**\n`;
        report += `- **Trang thai**: ${invoice.status} | Phe duyet: ${invoice.approvalStatus}\n\n`;

        report += `## 📈 Boi canh Tai chinh Hien tai\n`;
        report += `| Chi so | Gia tri |\n|---|---|\n`;
        report += `| Tong Phai Thu (AR) | ${formatVND(totalAr)} |\n`;
        report += `| Tong Phai Tra (AP) | ${formatVND(totalAp)} |\n`;
        report += `| Thanh toan thang nay | ${formatVND(paymentsThisMonth)} |\n`;
        report += `| Hoa don cho duyet khac | ${pendingApprovalCount} |\n`;
        if (apArRatio !== null) {
          report += `| Ty le AP/AR | ${(apArRatio * 100).toFixed(1)}% |\n`;
        }
        report += `| Hoa don nay / Tong AP | ${invoiceAsPercentAp.toFixed(1)}% |\n\n`;

        report += `## 🧾 Lich su Doi tac\n`;
        if (partnerTotal > 0) {
          report += `- Tong giao dich truoc: ${partnerTotal}\n`;
          report += `- Da phe duyet: ${partnerApproved} | Bi tu choi: ${partnerRejected}\n`;
        } else {
          report += `- Chua co lich su giao dich trong he thong.\n`;
        }
        report += "\n";

        if (positives.length > 0) {
          report += `## ✅ Diem Tich cuc\n`;
          positives.forEach((p) => (report += `- ${p}\n`));
          report += "\n";
        }

        if (risks.length > 0) {
          report += `## ⚠️ Yeu to Rui ro\n`;
          risks.forEach((r) => (report += `- ${r}\n`));
          report += "\n";
        }

        report += `---\n`;
        report += `## ${recommendationIcon} Khuyen nghi: **${recommendation}**\n\n`;

        if (riskScore >= 2) {
          report += `> Vui long xem xet cac yeu to rui ro tren truoc khi quyet dinh. `;
          report += `Co the su dung tool \`reject_invoice\` voi ly do ro rang hoac yeu cau doi tac cung cap them tai lieu.\n`;
        } else {
          report += `> Neu dong y voi phan tich tren, su dung tool \`approve_invoice\` de phe duyet hoa don nay.\n`;
        }

        // --- Tao suggested_comment de dung truc tiep khi approve/reject ---
        const partnerLabel = invoice.partnerName ?? invoice.partnerId;
        const invoiceLabel = invoice.invoiceNumber ? `HĐ ${invoice.invoiceNumber}` : `HĐ ${invoiceId.slice(0, 8)}`;

        let suggestedComment: string;
        if (riskScore === 0) {
          const positiveSummary = positives.slice(0, 2).join("; ");
          suggestedComment = `[AI Review] ${invoiceLabel} - ${partnerLabel} (${formatVND(invoiceAmount)}): Phe duyet. ${positiveSummary}.`;
        } else if (riskScore === 1) {
          suggestedComment = `[AI Review] ${invoiceLabel} - ${partnerLabel} (${formatVND(invoiceAmount)}): Phe duyet co dieu kien. Luu y: ${risks[0]}`;
        } else {
          const riskSummary = risks.slice(0, 2).map((r, i) => `(${i + 1}) ${r}`).join(" ");
          suggestedComment = `[AI Review] ${invoiceLabel} - ${partnerLabel} (${formatVND(invoiceAmount)}): De nghi tu choi. Ly do: ${riskSummary}`;
        }

        report += `\n---\n`;
        report += `## 💬 Comment gợi ý (dùng trực tiếp khi approve/reject)\n\n`;
        report += `\`\`\`\n${suggestedComment}\n\`\`\`\n\n`;
        report += `> Sao chép đoạn trên vào tham số \`comment\` của \`approve_invoice\` hoặc \`reject_invoice\`.\n`;

        return {
          content: [{ type: "text" as const, text: report }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  // ── Partners ───────────────────────────────────────────────────────────────

  server.tool(
    "list_partners",
    "Tim kiem va liet ke doi tac (khach hang AR hoac nha cung cap AP)",
    {
      search: z.string().optional().describe("Tim kiem theo ten hoac ma doi tac"),
      type: z.string().optional().describe("CUSTOMER | VENDOR"),
      page: z.number().default(0),
      size: z.number().default(20),
    },
    async (params) => {
      try {
        const response = await client.get("/api/core/v1/partners", {
          params: { ...params, companyId: ctx.companyId },
        });
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "get_partner",
    "Lay thong tin chi tiet cua mot doi tac",
    { id: z.string().describe("UUID cua doi tac") },
    async ({ id }) => {
      try {
        const response = await client.get(`/api/core/v1/partners/${id}`);
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "create_partner",
    "Tao doi tac moi (khach hang hoac nha cung cap)",
    {
      name: z.string().describe("Ten doi tac"),
      type: z.enum(["CUSTOMER", "VENDOR"]).describe("CUSTOMER: khach hang | VENDOR: nha cung cap"),
      email: z.string().email().optional(),
      phone: z.string().optional(),
      address: z.string().optional(),
      taxCode: z.string().optional().describe("Ma so thue"),
    },
    async (params) => {
      try {
        const response = await client.post("/api/core/v1/partners", {
          ...params,
          companyId: ctx.companyId,
        });
        const partner = response.data.data;
        return {
          content: [
            {
              type: "text" as const,
              text: `✅ Tao doi tac thanh cong!\nID: ${partner.id}\nTen: ${partner.name}\nLoai: ${partner.type}\n\n${JSON.stringify(partner, null, 2)}`,
            },
          ],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  // ── Payments ───────────────────────────────────────────────────────────────

  server.tool(
    "list_payments",
    "Liet ke danh sach thanh toan (Cash In / Cash Out), co the loc theo trang thai post",
    {
      posted: z.boolean().optional().describe("true: da post len so cai | false: chua post"),
      partnerId: z.string().optional(),
      page: z.number().default(0),
      size: z.number().default(20),
    },
    async (params) => {
      try {
        const response = await client.get("/api/core/v1/payments", {
          params: { ...params, companyId: ctx.companyId },
        });
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "get_payment",
    "Lay chi tiet mot thanh toan",
    { id: z.string().describe("UUID cua thanh toan") },
    async ({ id }) => {
      try {
        const response = await client.get(`/api/core/v1/payments/${id}`);
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "create_payment",
    "Tao thanh toan moi: CASH_IN (thu tien) hoac CASH_OUT (chi tien). Thanh toan duoc tao o trang thai chua post.",
    {
      paymentType: z.enum(["CASH_IN", "CASH_OUT"]).describe("CASH_IN: thu tien | CASH_OUT: chi tien"),
      partnerId: z.string().describe("UUID doi tac"),
      bankAccountId: z.string().describe("UUID tai khoan ngan hang cong ty"),
      amount: z.string().describe("So tien (string), vi du: '5000000'"),
      paymentDate: z.string().describe("Ngay thanh toan ISO, vi du: 2025-06-15"),
      invoiceId: z.string().optional().describe("UUID cua hoa don can thanh toan (neu muon lien ket truc tiep)"),
      description: z.string().optional().describe("Dien giai thanh toan"),
    },
    async (params) => {
      try {
        const response = await client.post("/api/core/v1/payments", {
          ...params,
          companyId: ctx.companyId,
        });
        const payment = response.data.data;
        return {
          content: [
            {
              type: "text" as const,
              text: `✅ Tao thanh toan thanh cong!\nID: ${payment.id}\nSo tien: ${formatVND(payment.amount)}\nLoai: ${payment.paymentType}\nTrang thai: ${payment.posted ? "Da post" : "Chua post"}\n\n${JSON.stringify(payment, null, 2)}`,
            },
          ],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "post_payment",
    "Post (ghi nhan chinh thuc) mot thanh toan len So Cai. Sau buoc nay, but toan ke toan duoc tao tu dong va thanh toan khong the sua.",
    { id: z.string().describe("UUID cua thanh toan can post") },
    async ({ id }) => {
      try {
        const response = await client.post(`/api/core/v1/payments/${id}/post`);
        const payment = response.data.data;
        return {
          content: [
            {
              type: "text" as const,
              text: `✅ Post thanh toan thanh cong! But toan ke toan da duoc tao.\nID: ${payment.id} | Da post: ${payment.posted}\n\n${JSON.stringify(payment, null, 2)}`,
            },
          ],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  // ── Reference Data ─────────────────────────────────────────────────────────

  server.tool(
    "list_accounts",
    "Lay danh muc tai khoan ke toan (Chart of Accounts - COA). Dung de tra cuu accountId khi tao hoa don.",
    {
      type: z.string().optional().describe("ASSET | LIABILITY | EQUITY | REVENUE | EXPENSE"),
      search: z.string().optional(),
      page: z.number().default(0),
      size: z.number().default(50),
    },
    async (params) => {
      try {
        const response = await client.get("/api/core/v1/accounting/accounts", {
          params: { ...params, companyId: ctx.companyId },
        });
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "list_journals",
    "Xem danh sach but toan ke toan kep (Journal Entries) duoc tao tu dong boi he thong. Chi doc, khong cho phep tao thu cong.",
    {
      page: z.number().default(0),
      size: z.number().default(20),
    },
    async (params) => {
      try {
        const response = await client.get("/api/core/v1/accounting/journals", {
          params: { ...params, companyId: ctx.companyId },
        });
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );

  server.tool(
    "list_bank_accounts",
    "Lay danh sach tai khoan ngan hang cua cong ty. Dung de lay bankAccountId khi tao thanh toan.",
    {
      page: z.number().default(0),
      size: z.number().default(20),
    },
    async (params) => {
      try {
        const response = await client.get("/api/core/v1/finance/bank-accounts", {
          params: { ...params, companyId: ctx.companyId },
        });
        return {
          content: [{ type: "text" as const, text: JSON.stringify(response.data.data, null, 2) }],
        };
      } catch (error: any) {
        return handleError(error);
      }
    }
  );
}
