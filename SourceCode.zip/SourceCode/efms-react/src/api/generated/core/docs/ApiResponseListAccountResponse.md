# ApiResponseListAccountResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **number** |  | [optional] [default to undefined]
**message** | **string** |  | [optional] [default to undefined]
**data** | [**Array&lt;AccountResponse&gt;**](AccountResponse.md) |  | [optional] [default to undefined]

## Example

```typescript
import { ApiResponseListAccountResponse } from './api';

const instance: ApiResponseListAccountResponse = {
    status,
    message,
    data,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
