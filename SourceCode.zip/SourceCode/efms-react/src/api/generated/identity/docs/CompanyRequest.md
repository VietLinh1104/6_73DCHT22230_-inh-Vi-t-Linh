# CompanyRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [default to undefined]
**currency** | **string** |  | [optional] [default to undefined]
**taxCode** | **string** |  | [optional] [default to undefined]
**address** | **string** |  | [optional] [default to undefined]
**isActive** | **boolean** |  | [optional] [default to undefined]

## Example

```typescript
import { CompanyRequest } from './api';

const instance: CompanyRequest = {
    name,
    currency,
    taxCode,
    address,
    isActive,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
