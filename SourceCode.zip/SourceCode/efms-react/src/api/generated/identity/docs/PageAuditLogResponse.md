# PageAuditLogResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalElements** | **number** |  | [optional] [default to undefined]
**totalPages** | **number** |  | [optional] [default to undefined]
**pageable** | [**PageableObject**](PageableObject.md) |  | [optional] [default to undefined]
**numberOfElements** | **number** |  | [optional] [default to undefined]
**first** | **boolean** |  | [optional] [default to undefined]
**last** | **boolean** |  | [optional] [default to undefined]
**size** | **number** |  | [optional] [default to undefined]
**content** | [**Array&lt;AuditLogResponse&gt;**](AuditLogResponse.md) |  | [optional] [default to undefined]
**number** | **number** |  | [optional] [default to undefined]
**sort** | [**Array&lt;SortObject&gt;**](SortObject.md) |  | [optional] [default to undefined]
**empty** | **boolean** |  | [optional] [default to undefined]

## Example

```typescript
import { PageAuditLogResponse } from './api';

const instance: PageAuditLogResponse = {
    totalElements,
    totalPages,
    pageable,
    numberOfElements,
    first,
    last,
    size,
    content,
    number,
    sort,
    empty,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
