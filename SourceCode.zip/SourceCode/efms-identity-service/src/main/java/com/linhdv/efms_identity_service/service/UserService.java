package com.linhdv.efms_identity_service.service;

import com.linhdv.efms_identity_service.dto.request.UserUpdateRequest;
import com.linhdv.efms_identity_service.dto.request.InviteUserRequest;
import com.linhdv.efms_identity_service.dto.request.ActivateUserRequest;
import com.linhdv.efms_identity_service.dto.response.UserResponse;
import com.linhdv.efms_identity_service.dto.response.UserInternalResponse;
import com.linhdv.efms_identity_service.entity.*;
import com.linhdv.efms_identity_service.mapper.UserMapper;
import com.linhdv.efms_identity_service.repository.RoleRepository;
import com.linhdv.efms_identity_service.repository.UserRepository;
import com.linhdv.efms_identity_service.repository.CompanyRepository;
import com.linhdv.efms_identity_service.security.jwt.JwtUtils;
import com.linhdv.efms_identity_service.security.services.UserDetailsImpl;
import com.linhdv.efms_identity_service.wrapper.PagedResponse;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.security.access.AccessDeniedException;

import lombok.NonNull;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpEntity;

import java.util.List;
import java.util.UUID;
import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private CompanyRepository companyRepository;

    @Value("${resend.api-key}")
    private String resendApiKey;

    @Value("${resend.from-email}")
    private String fromEmail;

    @Value("${efms.app.frontend-url}")
    private String frontendUrl;

    private static class InviteData {
        String email;
        UUID roleId;
        UUID companyId;
        Instant expiry;

        InviteData(String email, UUID roleId, UUID companyId, Instant expiry) {
            this.email = email;
            this.roleId = roleId;
            this.companyId = companyId;
            this.expiry = expiry;
        }
    }

    private final Map<String, InviteData> inviteStorage = new ConcurrentHashMap<>();

    @Transactional(readOnly = true)
    public PagedResponse<UserResponse> getAllUsers(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<User> userPage = userRepository.findAll(pageable);

        List<UserResponse> content = userPage.getContent().stream()
                .map(userMapper::toResponse)
                .collect(Collectors.toList());

        return PagedResponse.of(content, page, size, userPage.getTotalElements());
    }

    @Transactional(readOnly = true)
    public PagedResponse<UserResponse> getUsersByMyCompany(int page, int size) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (!(principal instanceof UserDetailsImpl)) {
            throw new AccessDeniedException("Unauthorized");
        }
        UUID companyId = ((UserDetailsImpl) principal).getCompanyId();

        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<User> userPage = userRepository.findByCompanyId(companyId, pageable);

        List<UserResponse> content = userPage.getContent().stream()
                .map(userMapper::toResponse)
                .collect(Collectors.toList());

        return PagedResponse.of(content, page, size, userPage.getTotalElements());
    }

    @Transactional(readOnly = true)
    public UserResponse getUserById(UUID id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + id));
        return userMapper.toResponse(user);
    }

    @Transactional
    public UserResponse updateUser(@NonNull UUID id, UserUpdateRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + id));

        if (request.getName() != null)
            user.setName(request.getName());
        if (request.getEmail() != null)
            user.setEmail(request.getEmail());
        if (request.getIsActive() != null)
            user.setIsActive(request.getIsActive());

        if (request.getRoleId() != null) {
            Role role = roleRepository.findById(request.getRoleId())
                    .orElseThrow(() -> new EntityNotFoundException("Role not found with id: " + request.getRoleId()));
            user.setRole(role);
        }

        user = userRepository.save(user);
        return userMapper.toResponse(user);
    }

    @Transactional
    public void deleteUser(UUID id) {
        userRepository.deleteById(id);
    }

    @Transactional
    public UserResponse setActiveUser(@NonNull UUID id, boolean isActive) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + id));

        user.setIsActive(isActive);
        user = userRepository.save(user);
        return userMapper.toResponse(user);
    }

    @Transactional(readOnly = true)
    public List<UserInternalResponse> getUsersBatch(Collection<UUID> ids, UUID companyId) {
        return userRepository.findAllByIdInAndCompanyId(ids, companyId).stream()
                .map(user -> UserInternalResponse.builder()
                        .id(user.getId())
                        .fullName(user.getName())
                        .email(user.getEmail())
                        .avatar(null) // Entity doesn't have avatar yet
                        .build())
                .collect(Collectors.toList());
    }

    public void inviteUser(InviteUserRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Email is already in use");
        }

        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (!(principal instanceof UserDetailsImpl)) {
            throw new AccessDeniedException("Unauthorized");
        }
        UUID companyId = ((UserDetailsImpl) principal).getCompanyId();

        // Generate a neat, short 16-character token
        String token = UUID.randomUUID().toString().replace("-", "").substring(0, 16);

        // Store it in the map with 24 hours expiration
        inviteStorage.put(token, new InviteData(
                request.getEmail(),
                request.getRoleId(),
                companyId,
                Instant.now().plus(24, ChronoUnit.HOURS)));

        try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(resendApiKey);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("from", fromEmail);
            requestBody.put("to", new String[] { request.getEmail() });
            requestBody.put("subject", "Lời mời tham gia công ty - EFMS");

            String baseFrontend = frontendUrl;
            if (baseFrontend.endsWith("/login")) {
                baseFrontend = baseFrontend.substring(0, baseFrontend.length() - 6);
            }
            if (baseFrontend.endsWith("/")) {
                baseFrontend = baseFrontend.substring(0, baseFrontend.length() - 1);
            }

            String activationLink = baseFrontend + "/auth/activate?token=" + token + "&email="
                    + request.getEmail();

            requestBody.put("html",
                    "<p>Xin chào,</p><p>Bạn đã được mời tham gia vào hệ thống EFMS.</p><p>Vui lòng click vào link sau để kích hoạt tài khoản: <a href='"
                            + activationLink + "'>" + "Kích hoạt tài khoản"
                            + "</a></p><p>Link này sẽ hết hạn trong 24 giờ.</p><p>Trân trọng!</p>");

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
            restTemplate.postForEntity("https://api.resend.com/emails", entity, String.class);
        } catch (Exception e) {
            inviteStorage.remove(token);
            throw new IllegalStateException("Failed to send invitation email");
        }
    }

    @Transactional
    public void activateUser(ActivateUserRequest request) {
        InviteData inviteData = inviteStorage.get(request.getToken());

        if (inviteData == null || inviteData.expiry.isBefore(Instant.now())) {
            if (inviteData != null) {
                inviteStorage.remove(request.getToken());
            }
            throw new IllegalArgumentException("Invalid or expired token");
        }

        if (userRepository.existsByEmail(inviteData.email)) {
            inviteStorage.remove(request.getToken());
            throw new IllegalArgumentException("Email is already in use");
        }

        Role role = roleRepository.findById(inviteData.roleId)
                .orElseThrow(() -> new EntityNotFoundException("Role not found"));

        Company company = companyRepository.findById(inviteData.companyId)
                .orElseThrow(() -> new EntityNotFoundException("Company not found"));

        User user = new User();
        user.setId(UUID.randomUUID());
        user.setName(request.getName());
        user.setEmail(inviteData.email);
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(role);
        user.setCompany(company);
        user.setIsActive(true);

        userRepository.save(user);

        // Remove the token after successful activation
        inviteStorage.remove(request.getToken());
    }
}
